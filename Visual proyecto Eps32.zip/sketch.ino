#include <WiFi.h>
#include <WebServer.h>

// Datos WiFi para Wokwi
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// Servidor Web
WebServer server(80);

// Variable compartida
int valorSensor = 0;

// MUTEX
SemaphoreHandle_t mutex;

// =========================
// TAREA 1: Leer Sensor
// =========================
void tareaSensor(void *parameter) {

  while (true) {

    int lectura = analogRead(34);

    if (xSemaphoreTake(mutex, portMAX_DELAY)) {

      valorSensor = lectura;

      xSemaphoreGive(mutex);
    }

    Serial.print("Sensor: ");
    Serial.println(lectura);

    vTaskDelay(1000 / portTICK_PERIOD_MS);
  }
}

// =========================
// PAGINA WEB
// =========================
void handleRoot() {

  int dato;

  if (xSemaphoreTake(mutex, portMAX_DELAY)) {

    dato = valorSensor;

    xSemaphoreGive(mutex);
  }

  String pagina = "";

  pagina += "<html>";
  pagina += "<head>";
  pagina += "<meta http-equiv='refresh' content='2'>";
  pagina += "</head>";

  pagina += "<body>";
  pagina += "<h1>Proyecto FreeRTOS y MUTEX</h1>";
  pagina += "<h2>Valor del Sensor</h2>";
  pagina += "<h3>" + String(dato) + "</h3>";
  pagina += "<p>Estado: Sistema Activo</p>";
  pagina += "</body>";
  pagina += "</html>";

  server.send(200, "text/html", pagina);
}

// =========================
// TAREA 2: SERVIDOR WEB
// =========================
void tareaServidor(void *parameter) {

  while (true) {

    server.handleClient();

    vTaskDelay(10 / portTICK_PERIOD_MS);
  }
}

// =========================
// SETUP
// =========================
void setup() {

  Serial.begin(115200);

  Serial.println("Conectando WiFi...");

  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {

    delay(500);
    Serial.print(".");
  }

  Serial.println("");
  Serial.println("WiFi conectado");

  Serial.print("IP: ");
  Serial.println(WiFi.localIP());

  mutex = xSemaphoreCreateMutex();

  server.on("/", handleRoot);

  server.begin();

  xTaskCreate(
    tareaSensor,
    "Sensor",
    2048,
    NULL,
    1,
    NULL
  );

  xTaskCreate(
    tareaServidor,
    "Servidor",
    4096,
    NULL,
    2,
    NULL
  );
}

// =========================
// LOOP
// =========================
void loop() {
}